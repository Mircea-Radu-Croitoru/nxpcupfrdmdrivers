#ifndef ESC_H
#define ESC_H

#include "fsl_pwm.h"


void SetESCSpeed(double Speed);


#endif // ESC_H
